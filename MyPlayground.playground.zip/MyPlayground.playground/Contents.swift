import UIKit

var number = [1, 4]


